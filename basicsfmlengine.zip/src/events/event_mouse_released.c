/*
** EPITECH PROJECT, 2021
** header
** File description:
** header
*/

#include "game.h"
#include "event.h"

int event_mouse_button_released(game_t *game, sfEvent event)
{
    (void)game;
    (void)event;
    return (1);
}
