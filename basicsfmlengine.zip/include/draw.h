/*
** EPITECH PROJECT, 2021
** header
** File description:
** header
*/

#ifndef DRAW_H_
#define DRAW_H_

int draw_background(game_t *game);

#endif /* DRAW_H_ */
